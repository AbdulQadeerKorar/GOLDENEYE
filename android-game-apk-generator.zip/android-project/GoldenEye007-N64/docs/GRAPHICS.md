# GoldenEye 007 — Graphics Settings Map

Every setting below is wired to a **real engine option** in Mupen64Plus-AE at the pinned
commit. In-game: swipe down → Settings → Video (per-game settings are under the game's
own settings page). Nothing here is a label-only preference.

## Rendering resolution
* **Setting:** *Rendered resolution* — `Native (highest quality)`, `320×240` … `1920×1440`,
  `2880×2160` … `5760×4320 (highest framerate label inverted: higher = sharper)`.
* Native N64 for GoldenEye is **320×240 interlaced**. 2× (640×480) is the sweet spot on
  phones; 4× on flagships (Galaxy S-class). Higher internal resolution + GLideN64
  framebuffer emulation fixes the blurry watch/scope HUD elements.
* With the **GLideN64** plugin you additionally get *Frame buffer emulation → Use native
  resolution factor* (Off/1×/2×/3×/4×) for effects rendered at native res.

## Anti-aliasing
* **FXAA — genuinely supported** (GLideN64): *Texture FXAA — Fast Approximate
  Anti-Aliasing*, plus FXAA as a display shader pass.
* **TAA — NOT supported.** The engine's plugins (GLideN64, gln64, rice, glide64,
  Parallel-RDP) do not implement temporal AA, so it is not offered anywhere.
  Supersampling via raised internal resolution is the honest high-quality alternative.
* **VI anti-aliasing / divot filter** (angrylion-rdp-plus, accurate software path):
  smooths polygon edges at N64 level.

## Synchronization / frame pacing
* *Synchronize audio and video* — the engine's VSync-equivalent (minimizes latency,
  may crackle on weak devices).
* *Buffer swapping method* — VI / conditions / mixed (frame-pacing behaviour).
* *Auto frameskip* and exact *Frameskip* (0–5 frames) — speed vs smoothness.
* Framerate counter position (Off / corners) for verifying pacing. No arbitrary "FPS
  limit" slider exists because the N64 VI drives timing; frameskip is the real control.

## Texture & image filtering
* *Bilinear filtering mode*: **N64 3-point** (authentic) / **Standard bilinear** / off
  (*Force point sampled* = nearest-neighbour).
* *Maximum anisotropic filtering*: **1× / 2× / 4× / 8× / 16×** (GLideN64).
* *Texture filtering*: Smooth 1-3 / Sharp 1-2; *Texture enhancement*: X2, X2SAI, HQ2X,
  HQ4X, 2xBRZ…6xBRZ, Deposterize.
* *2xSaI texture filter* (gln64 path) reduces pixellation.
* **Integer scaling** + *Hide overscan* + *Aspect ratio: Force 4:3 / Force 16:9 /
  Stretch / Original* (GLideN64). GoldenEye is **4:3** — stretching to 16:9 distorts
  aiming; the widescreen hack exists (*Adjust screen aspect for wide screen mode*) but
  GoldenEye renders genuine 3D outside 4:3 only partially — disclosed, not hidden.

## Post-processing shaders (Display Shaders menu — real passes)
Scan lines • Blur • **N64 Dither** (VI-filter approximation) • **FXAA** •
**CRT Geometry** • **ScaleFX**. Shader scale factor + per-pass configuration.

## Video plugin choice = the real "performance preset"
| Plugin | Character | GoldenEye use |
|---|---|---|
| `gliden64` (GLideN64) | GL accuracy + enhancements | **Recommended** — best HUD/watch rendering, FXAA, hires |
| `gln64` | Fast, basic | Battery saver on weak devices |
| `glide64` | Legacy compat | Fallback for glitches |
| `rice` | Legacy | Alternative fallback |
| `angrylion-rdp-plus` | Pixel-perfect software | Accuracy reference, heavy |
| `Parallel` (Vulkan) | Vulkan renderer | Modern GPUs, experimental |

## GoldenEye 007 recommended profile (Balanced)
Video plugin **gliden64** · Rendered resolution **640×480 (2×)** · FXAA **on** ·
Bilinear **N64 3-point** · Anisotropic **4×** · Aspect **Force 4:3** · Integer scaling
**on** · Audio sync **on** · Frameskip **never**.
Battery Saver: `gln64` + native resolution + frameskip 1. High Quality: `gliden64` +
1280×960 (4×) + FXAA + 16× anisotropic (flagship arm64 devices only).

## Honest limitations
* No TAA, no driver-level MSAA toggle, no arbitrary resolution multiplier beyond the
  engine's list — the plugin architecture does not expose them.
* Widescreen is a hack; GoldenEye's skyboxes/geometry are built for 4:3.
* GoldenEye's film-grain dithering can look noisier at high internal resolutions —
  *N64 Dither* shader or *Dithering quantization* options mitigate it.
