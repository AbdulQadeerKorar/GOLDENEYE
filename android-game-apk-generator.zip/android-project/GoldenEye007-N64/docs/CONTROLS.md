# GoldenEye 007 — Controls Guide

## The game's native control styles

GoldenEye 007 ships four single-player control styles. The default is **1.1 Honey**:

| N64 input | 1.1 Honey (default) | 1.2 Solitaire |
|---|---|---|
| Control Stick | Move + turn | **Look (camera)** + turn |
| C-Up / C-Down | **Look up / down (camera)** | Move forward / back |
| C-Left / C-Right | Strafe left / right | Strafe left / right |
| Z Trigger | **Fire** | **Fire** |
| B | Reload / action (doors) | Reload / action |
| A | Change weapon | Change weapon |
| L or R | Crosshair aim mode | Crosshair aim mode |
| Start | Pause / objectives | Pause / objectives |

You can switch style in-game (Pause → Controls). **For touch play with camera on the
right thumb, 1.1 Honey is the default and the overlay below is built for it.** If you
prefer moving with the C-buttons and aiming with the stick, switch to 1.2 Solitaire —
the same overlay works, the clusters simply trade roles.

## Dedicated touch layout (default profile)

```
┌────────────────────────────────────────────────────────────────┐
│                    [START]            [AIM L] [AIM R]          │
│                                                                │
│                                             ▲ C-UP             │
│    ┌─┐                                    ◄ C ►  CAMERA        │
│    │✛│  MOVE / TURN                         ▼ C-DOWN            │
│    └─┘                                                    WEAPON│
│                                                          (A)   │
│          [D-PAD]                                  FIRE (Z)     │
│                                                 ACTION (B)     │
└────────────────────────────────────────────────────────────────┘
```

* **Left thumb** — movement: floating analog stick (default) or D-pad. The stick is
  *relative* (re-centers where you touch) so there are no stuck directions when a finger
  lifts mid-move; multi-touch keeps movement and fire independent.
* **Right thumb** — camera: the C-button cross sits on the **right** so camera look is
  done on the right side of the screen, exactly as requested. FIRE (Z) is the large
  button under it, ACTION (B) and WEAPON (A) complete the cluster.
* **Top right** — AIM L / AIM R (shoulder buttons) enter GoldenEye's crosshair aim mode.
* All buttons are labelled with their in-game action (FIRE / ACTION / WEAPON / AIM),
  not raw N64 letters.

## Customizing the layout (in-app, real editor — not decorative)

Swipe down in-game → **Settings → Touchscreen**:

1. **Buttons** — every control listed individually. For each one:
   * drag to reposition (independent Horizontal % / Vertical % fields for exact values),
   * **Scaling %** per control (free range, no fixed presets),
   * remove/add controls (e.g. swap D-pad ↔ analog stick, split or merge the C-pad,
     add a second Z button), auto-hold behaviour, hide-when-sensor-active.
2. **Global** — *Button opacity* and *Button scale* sliders, button style
   (Outlines / Shaded / Flat / HiRes / Colored / Custom), joystick animation,
   X/Y sensitivity and deadzone, invert axes, *Relative touchscreen joystick*
   (floating stick on/off), auto-hide timeout.
3. **Profiles** — save/load named touchscreen profiles (e.g. "GoldenEye Honey",
   "GoldenEye Solitaire", "Portrait"), separate from controller profiles.
   Editing mode is a dedicated editor screen: rearranging controls there never
   triggers gameplay inputs.
4. **D-pad specifics** — size/scale free, 4-way digital input with proper multi-touch;
   diagonals arrive as simultaneous direction inputs to the core. If you want analog
   movement, switch the control to the **Analog stick** widget — the engine feeds true
   analog values (0…127 per axis) to the N64 core, not simulated digitals.

## Camera by swipe (optional)

If you prefer swiping to look instead of tapping C-buttons: Settings → Touchscreen →
enable the touch-sensor/mouse mapping (the engine's "Touch screen or joystick…" input
sensor) and place the sensor over the right half of the screen. The C-button cluster
remains available for precise single-step look (sniping, tower shots on Facility).
This is an engine feature you toggle — the overlay does not fake it.

## Physical controllers

Settings → Input → **Controller** profiles: any Android gamepad (Bluetooth/USB, e.g.
Xbox, PS, 8BitDo) is auto-detected. Map each N64 input (A, B, C×4 or C-pad axes, Z, L,
R, Start, analog axes) per player — four controller profiles for multiplayer.
Touchscreen and gamepad can run simultaneously (combined mode): the touch overlay stays
active while a pad is connected. A typical GoldenEye pad mapping:
left stick = move/turn, right stick = C-pad (camera), RT/ZR = Z (fire), X/Square = B,
Y/Triangle = A, LB/RB = L/R aim.
