#!/usr/bin/env bash
# =============================================================================
# GoldenEye 007 branding overlay for the Mupen64Plus-AE engine source tree.
#
# Usage:  apply-overlay.sh <engine-source-dir> <overlay-dir>
#
# This script is intentionally strict: if the pinned engine layout no longer
# matches what the overlay expects, it aborts with a precise error instead of
# producing a half-branded APK.
# =============================================================================
set -euo pipefail

ENGINE_DIR="${1:?Usage: apply-overlay.sh <engine-source-dir> <overlay-dir>}"
OVERLAY_DIR="${2:?Usage: apply-overlay.sh <engine-source-dir> <overlay-dir>}"

STRINGS_FILE="$ENGINE_DIR/app/src/main/res/values/strings.xml"
APP_GRADLE="$ENGINE_DIR/app/build.gradle"
MASTER_ICON="$OVERLAY_DIR/icons/ic_launcher_master.png"

fail() { echo "OVERLAY ERROR: $*" >&2; exit 1; }

[ -d "$ENGINE_DIR/app/src/main" ] || fail "engine source dir not found: $ENGINE_DIR/app/src/main"
[ -f "$STRINGS_FILE" ]            || fail "strings.xml not found at $STRINGS_FILE (upstream layout changed?)"
[ -f "$APP_GRADLE" ]              || fail "app/build.gradle not found at $APP_GRADLE (upstream layout changed?)"
[ -f "$MASTER_ICON" ]             || fail "master icon missing: $MASTER_ICON"

echo "==> [1/4] Renaming application label to 'GoldenEye 007'"
if grep -q '<string name="app_name"' "$STRINGS_FILE"; then
  sed -i 's|<string name="app_name">[^<]*</string>|<string name="app_name">GoldenEye 007</string>|' "$STRINGS_FILE"
  grep -q '>GoldenEye 007<' "$STRINGS_FILE" || fail "app_name rename could not be verified in $STRINGS_FILE"
  echo "    OK: app_name = GoldenEye 007"
else
  fail 'no <string name="app_name"> entry found in strings.xml — update the overlay for the new engine layout'
fi

echo "==> [2/4] Appending Gradle branding (applicationId + APK output name)"
cat "$OVERLAY_DIR/gradle/goldeneye-branding.gradle" >> "$APP_GRADLE"
grep -q 'com.goldeneye007.n64' "$APP_GRADLE" || fail "applicationId override could not be verified in $APP_GRADLE"
grep -q 'GoldenEye007-N64-'   "$APP_GRADLE" || fail "APK output name override could not be verified in $APP_GRADLE"
echo "    OK: applicationId = com.goldeneye007.n64, output = GoldenEye007-N64-<buildType>.apk"

echo "==> [3/4] Replacing launcher icons"
REPLACED=0
while IFS= read -r ICON; do
  if command -v identify >/dev/null 2>&1 && command -v convert >/dev/null 2>&1; then
    WIDTH="$(identify -format '%w' "$ICON" 2>/dev/null || echo 192)"
    case "$WIDTH" in (*[!0-9]*|'') WIDTH=192 ;; esac
    convert "$MASTER_ICON" -resize "${WIDTH}x${WIDTH}!" "$ICON"
  else
    cp -f "$MASTER_ICON" "$ICON"
  fi
  echo "    replaced: ${ICON#"$ENGINE_DIR"/}"
  REPLACED=$((REPLACED + 1))
done < <(find "$ENGINE_DIR/app/src/main/res" -type f -name 'ic_launcher.png' | sort)
echo "    OK: $REPLACED launcher icon slot(s) updated (0 = engine uses non-PNG icons; label branding still applies)"

echo "==> [4/4] Final verification"
grep -q 'GoldenEye 007'      "$STRINGS_FILE" || fail "final verification failed: app label"
grep -q 'com.goldeneye007.n64' "$APP_GRADLE" || fail "final verification failed: applicationId"
echo "    OK: overlay applied cleanly."
