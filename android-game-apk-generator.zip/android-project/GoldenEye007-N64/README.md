# GoldenEye 007 — Dedicated N64 Android APK Project

A **single-game** Android application for *GoldenEye 007* (Nintendo 64, Rare, 1997).
This repository does **not** contain the emulator source directly. Instead it contains a
complete, verified **build pipeline**: the GitHub Actions workflow clones the open-source
**Mupen64Plus-AE** engine (the codebase behind *M64Plus FZ*) at a **pinned, SHA-verified
commit**, applies the GoldenEye 007 branding overlay in this ZIP, compiles the engine
(including its native N64 core and GLideN64 video plugin) for your device's ABI, and
uploads a ready-to-install APK artifact.

```
GoldenEye007-N64-Project.zip  ──►  unzip  ──►  overlay/ + pins/ + docs/
                                    │
        clone mupen64plus-ae @ 33bf7021 (SHA-verified)
                                    │
        apply-overlay.sh  (label, applicationId, APK name, launcher icon)
                                    │
        ./gradlew assemble  (Gradle 9.5.0 via wrapper, JDK 21, NDK)
                                    │
        app/build/outputs/apk/release/GoldenEye007-N64-release.apk
```

## What is in this ZIP

| Path | Purpose |
|---|---|
| `pins/mupen64plus-ae.sha` | Exact upstream engine commit the build is pinned to |
| `overlay/apply-overlay.sh` | Applies GoldenEye branding to the engine source tree (fails loudly if upstream layout changed) |
| `overlay/gradle/goldeneye-branding.gradle` | Sets `applicationId = com.goldeneye007.n64` and the `GoldenEye007-N64-*.apk` output name |
| `overlay/icons/ic_launcher_master.png` | Golden-eye launcher icon (scaled onto the engine's existing icon slots) |
| `docs/CONTROLS.md` | GoldenEye control styles, touchscreen layout, camera-on-right scheme, physical controllers |
| `docs/GRAPHICS.md` | Every graphics setting mapped to the real engine option that controls it |
| `.github/workflows/android-build.yml` | Copy of the CI workflow (authoritative copy lives at the repo root path) |

## What you must supply yourself

* **A legally obtained GoldenEye 007 ROM** — `.z64`, `.n64`, `.v64` (optionally inside
  `.zip`/`.7z`). Import it in-app with the ROM picker / "Refresh ROMs" scan.
  **No ROM, BIOS, or game data is bundled** — the N64 platform itself needs no BIOS file;
  the only copyrighted artifact is the game cartridge dump, which you provide.

## Emulator / licensing

* Engine: **Mupen64Plus-AE** (GPL-2.0+) — https://github.com/mupen64plus-ae/mupen64plus-ae
* Core/plugins: Mupen64Plus core (GPL-2.0+), **GLideN64** (GPL-2.0), plus gln64, rice,
  glide64, angrylion-rdp-plus and Parallel-RDP backends shipped by the engine.
* The compiled APK may be freely distributed under GPL terms; attribution is preserved
  in-app (Settings → About → Credits). See `LICENSE.md`.

## Controls (GoldenEye 007, default "1.1 Honey" style)

| Touch control | N64 input | In-game action |
|---|---|---|
| Left stick / D-pad (left side) | Control Stick / Pad | Move + turn |
| C-button cluster (right side) | C-Up/Down/Left/Right | **Camera look** (up/down) + strafe (left/right) |
| FIRE (large, red, right) | Z Trigger | Fire weapon |
| ACTION (gold, right) | B | Reload / open doors / interact |
| WEAPON (right) | A | Change weapon |
| AIM L / AIM R (top right) | L / R shoulder | Crosshair aim mode |
| START (top center) | Start | Pause / objectives |

Every overlay control is a real emulator input. In-game, open the swipe-down menu →
**Settings → Touchscreen → Buttons** to drag any control, set per-button
Horizontal/Vertical/Scaling %, opacity, style, auto-hold, and to save named touchscreen
profiles. Full guide in `docs/CONTROLS.md`.

## Building locally (optional)

```bash
unzip GoldenEye007-N64-Project.zip -d project
git clone https://github.com/mupen64plus-ae/mupen64plus-ae.git engine
cd engine && git checkout "$(tr -d '[:space:]' < ../project/GoldenEye007-N64/pins/mupen64plus-ae.sha)" && cd ..
bash project/GoldenEye007-N64/overlay/apply-overlay.sh "$PWD/engine" "$PWD/project/GoldenEye007-N64/overlay"
cd engine && ./gradlew assemble   # needs JDK 21 + Android SDK + NDK
```

Recommended: just push the ZIP + workflow to GitHub and let Actions build it
(see the delivery notes that accompany this ZIP).

## Troubleshooting

* **ZIP integrity error in CI** — re-upload the ZIP unmodified (binary-safe upload).
* **`app_name` / icon step fails** — upstream engine layout changed after the pinned
  commit; the overlay exits with a precise message instead of producing a half-branded APK.
* **No audio / slow on old devices** — in-game Settings → Video plugin: try `gln64`
  (fast) or `gliden64` (quality); see `docs/GRAPHICS.md` presets.
