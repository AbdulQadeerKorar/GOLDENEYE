# Licensing

This project builds a derivative of **Mupen64Plus-AE**, which is licensed under the
**GNU General Public License v2 (or later)**.

Upstream components compiled into the produced APK and their licenses:

| Component | License | Source |
|---|---|---|
| Mupen64Plus-AE (Android front-end) | GPL-2.0+ | https://github.com/mupen64plus-ae/mupen64plus-ae |
| Mupen64Plus core, RSP/HLE, audio, input plugins | GPL-2.0+ | https://github.com/mupen64plus |
| GLideN64 video plugin | GPL-2.0 | https://github.com/gonetz/GLideN64 |
| gln64 / rice / glide64 adaptations | GPL-2.0+ | bundled in Mupen64Plus-AE tree |
| angrylion-rdp-plus | GPL-2.0 | bundled in Mupen64Plus-AE tree |
| Parallel-RDP / vulkan-headers | GPL-2.0 / Apache-2.0 | bundled in Mupen64Plus-AE tree |

The complete corresponding source code for the compiled APK is the pinned upstream
commit referenced in `pins/mupen64plus-ae.sha` plus the overlay in this ZIP — both
publicly available, satisfying GPL source-distribution requirements.

**No game ROMs, BIOS files, firmware, or other copyrighted game data are distributed
with this project.** GoldenEye 007 © 1997 Rare Ltd./Nintendo. You must supply your own
legally obtained cartridge dump.

The launcher icon in `overlay/icons/` is an original fan-styled graphic created for
this build (gold eye + reticle motif); it contains no Nintendo/Rare assets.
