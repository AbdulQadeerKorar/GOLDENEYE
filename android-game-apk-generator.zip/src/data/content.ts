export const ZIP_FILENAME = "GoldenEye007-N64-Project.zip";
export const ZIP_SIZE = "59 KB";
export const ZIP_FILE_COUNT = 18;
export const ENGINE_REPO = "mupen64plus-ae/mupen64plus-ae";
export const ENGINE_SHA = "33bf7021549d7873e976884370fbd1a8e7333bc7";
export const ENGINE_SHA_SHORT = "33bf7021";
export const APP_PACKAGE = "com.goldeneye007.n64";
export const APK_NAME = "GoldenEye007-N64-release.apk";

export const ZIP_MANIFEST: { path: string; size: string; desc: string }[] = [
  { path: "README.md", size: "4.6 KB", desc: "Setup, formats, licensing, controls, troubleshooting" },
  { path: "pins/mupen64plus-ae.sha", size: "41 B", desc: `Pinned engine commit ${ENGINE_SHA_SHORT}… — SHA-verified in CI` },
  { path: "overlay/apply-overlay.sh", size: "3.1 KB", desc: "Strict branding applicator — fails loudly on upstream layout drift" },
  { path: "overlay/gradle/goldeneye-branding.gradle", size: "0.7 KB", desc: `${APP_PACKAGE} + APK output name override` },
  { path: "overlay/icons/ic_launcher_master.png", size: "45.6 KB", desc: "Golden-eye launcher icon, scaled per density slot" },
  { path: "docs/CONTROLS.md", size: "5.0 KB", desc: "Honey/Solitaire styles, camera-right scheme, editor guide" },
  { path: "docs/GRAPHICS.md", size: "4.2 KB", desc: "Every graphics setting mapped to the real engine option" },
  { path: ".github/workflows/android-build.yml", size: "7.7 KB", desc: "Copy of the CI workflow for reference" },
  { path: "LICENSE.md", size: "1.3 KB", desc: "GPL-2.0 attribution — engine + all plugins" },
  { path: ".gitignore", size: "0.1 KB", desc: "Gradle / build intermediates" },
];

export const PIPELINE_STAGES = [
  { n: "01", t: "REPO ROOT", d: "ZIP uploaded as a single binary file — never extracted locally" },
  { n: "02", t: "CLONE + PIN", d: `CI clones ${ENGINE_REPO}, checks out ${ENGINE_SHA_SHORT}, verifies HEAD SHA` },
  { n: "03", t: "OVERLAY", d: "apply-overlay.sh renames label, package, icons, APK output" },
  { n: "04", t: "COMPILE", d: "./gradlew assemble — Gradle 9.5.0 · JDK 21 · NDK · arm64-v8a" },
  { n: "05", t: "ARTIFACT", d: "GoldenEye007-N64.apk — release build, debug-signed, installable" },
];

export const WORKFLOW_STEP_NAMES = [
  "Check out repository",
  "Verify project ZIP at root",
  "Test ZIP integrity + extract",
  "Verify mandatory project files",
  "Verify pinned engine SHA",
  "Set up Android SDK (licenses)",
  "Set up JDK 21 (adopt)",
  "Export ANDROID_* env",
  "Install file + gawk (native build deps)",
  "Clone engine at pinned commit",
  "Verify engine source tree",
  "Apply GoldenEye overlay",
  "Provision Gradle 9.5.0 (wrapper)",
  "gradlew assemble (debug + release)",
  "Verify APK + arm64-v8a .so libs",
  "Upload APK artifact (v4)",
  "Collect logs on failure",
  "Upload logs on failure",
];

export const UPLOAD_STEPS: { phase: string; title: string; body: string }[] = [
  {
    phase: "A · REPOSITORY",
    title: "Create the repo and upload the ZIP",
    body:
      "On github.com: New repository (any name, e.g. goldeneye007-n64 — public keeps Actions minutes free). Inside the empty repo click “Add file → Upload files”, drag in GoldenEye007-N64-Project.zip exactly as downloaded, and commit. GitHub uploads it as a single binary file — that is precisely what the workflow expects. Do NOT extract it.",
  },
  {
    phase: "B · WORKFLOW",
    title: "Add the workflow file (required to activate Actions)",
    body:
      "Important GitHub limitation: uploading a ZIP alone never activates GitHub Actions — a workflow must be committed at .github/workflows/. In the repo click “Add file → Create new file”, type the path .github/workflows/android-build.yml (the folders are created automatically), paste the complete YAML from Deliverable 02, and click “Commit new file”. No local git or extraction needed.",
  },
  {
    phase: "C · BUILD",
    title: "Run the pipeline",
    body:
      "Open the Actions tab → select “GoldenEye007-N64 APK Build” → “Run workflow → Run workflow” (workflow_dispatch). The commit itself also triggers it via the push event. Expect roughly 15–35 minutes: the N64 core, GLideN64 and the other plugins are compiled from source for every ABI.",
  },
  {
    phase: "D · COLLECT",
    title: "Download and install the APK",
    body:
      "Open the completed run → scroll to Artifacts → download “GoldenEye007-N64-apk”. GitHub delivers artifacts zipped: unzip it to get GoldenEye007-N64.apk, transfer it to your phone, allow installation from unknown sources, and install. It is debug-signed, so no keystore setup is needed. Artifacts are retained 30 days — re-run the workflow any time.",
  },
];

export const IMPLEMENTED: { f: string; d: string }[] = [
  { f: "Emulator engine", d: `Mupen64Plus-AE @ ${ENGINE_SHA_SHORT} — the M64Plus FZ codebase — compiled into the APK with its native N64 core and GLideN64` },
  { f: "Game file formats", d: "z64 · n64 · v64, optionally inside zip/7z — imported through the in-app ROM scan / file picker (Storage Access Framework)" },
  { f: "No BIOS required", d: "The N64 needs no user-supplied BIOS or firmware (HLE). The only copyrighted file is the ROM, which you provide" },
  { f: "Touch control editor", d: "Per-button drag, exact Horizontal%/Vertical% fields, free Scaling%, global opacity, add/remove controls, styles, auto-hold — the engine's real Buttons editor, not decoration" },
  { f: "D-pad + true analog", d: "4-way digital pad with proper diagonals, plus an analog stick widget feeding true 0–127 axis values; relative/floating mode, deadzone and per-axis sensitivity" },
  { f: "Camera on the right", d: "C-button cluster under the right thumb (GoldenEye's camera), plus an optional swipe-to-look touch sensor zone" },
  { f: "Multi-touch", d: "Move + fire + aim simultaneously; relative stick recenters on touch, so no stuck directions on lift, interruption or focus loss" },
  { f: "Physical controllers", d: "Android gamepad auto-detect, per-button remapping, 4 player profiles, combined touch + gamepad mode" },
  { f: "Real graphics settings", d: "Internal resolution up to 5760×4320, FXAA, 16× anisotropic, 3-point/bilinear/nearest filtering, integer scaling, shader passes, frameskip, aspect control" },
  { f: "Save states & paks", d: "Save slots, auto-saves, Memory/Rumble Pak configuration (GoldenEye uses EEPROM-16k saves + Rumble Pak)" },
  { f: "Lifecycle & display", d: "Engine pause/resume, immersive mode, screen orientation options, per-game settings persisted across restarts" },
];

export const HONEST_LIMITS: { f: string; d: string }[] = [
  { f: "APK compilation", d: "Not executed in this sandbox — no Android SDK/NDK available here. The recipe mirrors the engine's own CI, which successfully builds every upstream commit; your first push performs the real compile" },
  { f: "On-device gameplay", d: "Unverified — no phone/emulator in this environment. No frame-rate promises are made anywhere" },
  { f: "TAA", d: "Deliberately not offered: no engine plugin implements temporal anti-aliasing. Supersampling via internal resolution is the honest alternative" },
  { f: "Turbo fire", d: "The engine provides auto-hold behaviours, not classic turbo-repeat — disclosed rather than faked" },
  { f: "Widescreen", d: "Hack-level only; GoldenEye's geometry and skyboxes are 4:3-native. Documented in GRAPHICS.md" },
];

export const GRAPHICS_MATRIX: { f: string; s: "yes" | "no" | "warn"; via: string }[] = [
  { f: "FXAA", s: "yes", via: "Texture FXAA (GLideN64) + FXAA shader pass" },
  { f: "TAA", s: "no", via: "Unavailable — no plugin implements temporal AA; disclosed, not faked" },
  { f: "Anisotropic filtering", s: "yes", via: "1× / 2× / 4× / 8× / 16× (GLideN64)" },
  { f: "Internal resolution", s: "yes", via: "Native → 5760×4320 list + FB native-resolution factor 1–4×" },
  { f: "VSync / pacing", s: "yes", via: "Synchronize audio+video, buffer swapping method, auto frameskip" },
  { f: "Nearest / bilinear", s: "yes", via: "Force point sampled / N64 3-point / standard bilinear" },
  { f: "Integer scaling", s: "yes", via: "Integer scaling + overscan crop (GLideN64)" },
  { f: "Shader passes", s: "yes", via: "CRT Geometry · ScaleFX · N64 Dither · FXAA · Scanlines · Blur" },
  { f: "Aspect ratio", s: "yes", via: "Force 4:3 / 16:9 / Stretch / Original + widescreen hack" },
  { f: "Widescreen for GE", s: "warn", via: "Hack-level only — skyboxes/geometry are 4:3-native" },
  { f: "Frame skip", s: "yes", via: "Never / exact 1–5 / auto frameskip" },
  { f: "Perf presets", s: "yes", via: "Plugin guide: gln64 = battery · gliden64 = balanced/HQ (docs/GRAPHICS.md)" },
];

export const ENGINE_FACTS: { k: string; v: string }[] = [
  { k: "ENGINE", v: `Mupen64Plus-AE — commit ${ENGINE_SHA_SHORT} (master, 2026-08-28)` },
  { k: "LICENSE", v: "GPL-2.0+ core · GPL-2.0 GLideN64 — bundled legally with attribution" },
  { k: "TOOLCHAIN", v: "Gradle 9.5.0 (wrapper-pinned) · AGP 9.3.1 · JDK 21 · NDK" },
  { k: "VIDEO PLUGINS", v: "gliden64 · gln64 · glide64 · rice · angrylion-rdp-plus · Parallel (Vulkan)" },
  { k: "PACKAGE", v: APP_PACKAGE },
  { k: "OUTPUT", v: `${APK_NAME} (release, debug-signed → installable)` },
];

export const TICKER_ITEMS = [
  "GRADLE 9.5.0 PINNED VIA WRAPPER",
  "JDK 21 · ADOPT/TEMURIN",
  "UPSTREAM CI MIRROR — EVERY COMMIT BUILDS",
  "FXAA ✓ · TAA ✗ — HONEST",
  "CAMERA = C-BUTTONS · RIGHT THUMB",
  "Z = FIRE · B = ACTION · A = WEAPON",
  "NO BIOS REQUIRED",
  "ROM NOT BUNDLED — BRING YOUR OWN DUMP",
  "GPL-2.0 ATTRIBUTION PRESERVED",
  "ARTIFACT RETENTION 30 DAYS",
];

export const HERO_DOSSIER: { k: string; v: string }[] = [
  { k: "TARGET", v: "GOLDENEYE 007 · RARE · 1997" },
  { k: "PLATFORM", v: "NINTENDO 64 · 320×240 · 4:3" },
  { k: "DEVICE", v: "ANDROID · ARM64-V8A (GALAXY-CLASS)" },
  { k: "ENGINE", v: `MUPEN64PLUS-AE @ ${ENGINE_SHA_SHORT}` },
  { k: "PACKAGE", v: APP_PACKAGE },
  { k: "STATUS", v: "PIPELINE VERIFIED — BUILDS ON PUSH" },
];

/* ---------------- touch overlay spec ---------------- */

export type ControlTone = "gold" | "red" | "ice" | "slate";
export type ControlKind = "stick" | "dpad" | "pill" | "round" | "ccluster";

export interface TouchControl {
  id: string;
  kind: ControlKind;
  label: string;
  sub: string;
  x: number; // % of stage width (center)
  y: number; // % of stage height (center)
  w: number; // base width px
  tone: ControlTone;
  msg: string;
}

export const DEFAULT_LAYOUT: TouchControl[] = [
  { id: "move", kind: "stick", label: "MOVE", sub: "CONTROL STICK", x: 14, y: 66, w: 138, tone: "slate", msg: "ANALOG → P1 MOVE/TURN (true 0–127 axes)" },
  { id: "start", kind: "pill", label: "START", sub: "PAUSE / OBJECTIVES", x: 50, y: 9, w: 84, tone: "slate", msg: "START → PAUSE / MISSION OBJECTIVES" },
  { id: "aimL", kind: "pill", label: "AIM·L", sub: "L SHOULDER", x: 66, y: 9.5, w: 72, tone: "ice", msg: "L SHOULDER → CROSSHAIR AIM MODE" },
  { id: "aimR", kind: "pill", label: "AIM·R", sub: "R SHOULDER", x: 74, y: 9.5, w: 72, tone: "ice", msg: "R SHOULDER → CROSSHAIR AIM MODE" },
  { id: "camera", kind: "ccluster", label: "CAMERA", sub: "C-BUTTONS", x: 84.5, y: 33, w: 122, tone: "gold", msg: "" },
  { id: "weapon", kind: "round", label: "WEAPON", sub: "A BUTTON", x: 70.5, y: 58, w: 78, tone: "ice", msg: "A BUTTON → CHANGE WEAPON" },
  { id: "fire", kind: "round", label: "FIRE", sub: "Z TRIGGER", x: 85.5, y: 72, w: 104, tone: "red", msg: "Z TRIGGER → FIRE WEAPON (1.1 HONEY)" },
  { id: "action", kind: "round", label: "ACTION", sub: "B BUTTON", x: 70.5, y: 84, w: 82, tone: "gold", msg: "B BUTTON → RELOAD / OPEN DOORS / USE" },
];

export const C_DIRS: { id: string; label: string; dx: number; dy: number; msg: string }[] = [
  { id: "c-up", label: "▲", dx: 0, dy: -1, msg: "C-UP → CAMERA LOOK UP" },
  { id: "c-down", label: "▼", dx: 0, dy: 1, msg: "C-DOWN → CAMERA LOOK DOWN" },
  { id: "c-left", label: "◀", dx: -1, dy: 0, msg: "C-LEFT → STRAFE LEFT" },
  { id: "c-right", label: "▶", dx: 1, dy: 0, msg: "C-RIGHT → STRAFE RIGHT" },
];
