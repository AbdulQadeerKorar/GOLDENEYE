import { ZIP_DATA_URI } from "./zipPayload";

/**
 * The project archive is embedded in the bundle as a base64 data URI,
 * so the download works even when only the single HTML file is served —
 * the payload can never 404.
 */
export const ZIP_URL: string = ZIP_DATA_URI;
