import { useState } from "react";
import WORKFLOW_YAML from "@/data/android-build.yml?raw";
import { ENGINE_SHA_SHORT, WORKFLOW_STEP_NAMES } from "@/data/content";

export function WorkflowSection() {
  const [copied, setCopied] = useState(false);
  const lines = WORKFLOW_YAML.replace(/\s+$/, "").split("\n");

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(WORKFLOW_YAML);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = WORKFLOW_YAML;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="workflow" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="reveal mb-10">
        <p className="font-mono text-[11px] tracking-[0.3em] text-gold">03 / DELIVERABLE — CI WORKFLOW</p>
        <h2 className="mt-2 font-display text-5xl font-extrabold tracking-tight text-paper sm:text-6xl">
          ONE YAML. <span className="text-gold">EIGHTEEN GATES.</span> NO GUESSWORK.
        </h2>
        <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-muted">
          Mirrors the engine's own production CI — JDK 21, the Android cmdline-tools version,
          the gawk/file build deps and the exact <span className="font-mono text-[13px] text-paper">gradlew assemble</span> recipe
          that compiles every upstream commit — with the GoldenEye gates bolted on: ZIP integrity,
          SHA-pinned engine checkout, mandatory-file checks, native-library verification, artifact upload.
        </p>
        <div className="hazard mt-5 w-56" />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        {/* code viewer */}
        <div className="reveal hud-panel hud-corners overflow-hidden">
          <div className="flex items-center justify-between border-b border-edge bg-panel2 px-4 py-2.5">
            <p className="truncate font-mono text-[11px] text-goldbright">.github/workflows/android-build.yml</p>
            <div className="flex items-center gap-3">
              <span className="hidden font-mono text-[10px] text-faint sm:block">{lines.length} LINES · PARSED ✓</span>
              <button
                onClick={copy}
                className={`border px-3 py-1 font-mono text-[11px] tracking-[0.15em] transition-colors ${copied ? "border-gold bg-golddark/60 text-goldbright" : "border-edge2 text-muted hover:border-gold hover:text-goldbright"}`}
              >
                {copied ? "✓ COPIED" : "⧉ COPY FULL YAML"}
              </button>
            </div>
          </div>
          <div className="code-scroll max-h-[560px] overflow-auto bg-abyss/80 p-4">
            <pre className="font-mono text-[11.5px] leading-[1.55]">
              {lines.map((line, i) => (
                <div key={i} className="flex">
                  <span className="w-9 shrink-0 select-none pr-3 text-right text-faint">{i + 1}</span>
                  <span
                    className={
                      /^\s*#/.test(line)
                        ? "text-faint"
                        : /^[\w-]+:/.test(line)
                          ? "text-goldbright"
                          : /name:|uses:|run:/.test(line)
                            ? "text-paper/90"
                            : "text-ice/80"
                    }
                  >
                    {line || " "}
                  </span>
                </div>
              ))}
            </pre>
          </div>
        </div>

        {/* pipeline gates */}
        <div className="reveal space-y-6">
          <div className="hud-panel p-5">
            <p className="mb-4 font-mono text-[10px] tracking-[0.3em] text-muted">PIPELINE GATES — EXECUTION ORDER</p>
            <ol className="space-y-2">
              {WORKFLOW_STEP_NAMES.map((name, i) => (
                <li key={name} className="group flex items-center gap-3 font-mono text-[11px] text-paper/80 transition-colors hover:text-goldbright">
                  <span className="grid h-5 w-7 shrink-0 place-items-center border border-edge2 bg-panel2 text-[9px] text-gold group-hover:border-gold">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  {name}
                </li>
              ))}
            </ol>
          </div>

          <div className="hud-panel p-5">
            <p className="mb-3 font-mono text-[10px] tracking-[0.3em] text-muted">HARD-CODED TRUTHS</p>
            <ul className="space-y-2 font-mono text-[11px] leading-relaxed text-muted">
              <li><span className="text-goldbright">ENGINE</span> — cloned at {ENGINE_SHA_SHORT}; HEAD SHA re-verified after checkout</li>
              <li><span className="text-goldbright">GRADLE</span> — 9.5.0, pinned by the engine's wrapper (provisioned + printed before build)</li>
              <li><span className="text-goldbright">APK</span> — must contain arm64-v8a .so libraries or the job fails loudly</li>
              <li><span className="text-goldbright">FAILURE</span> — gradle/hs_err logs captured and uploaded as a second artifact</li>
              <li><span className="text-goldbright">TRIGGERS</span> — push + workflow_dispatch (manual “Run workflow”)</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
