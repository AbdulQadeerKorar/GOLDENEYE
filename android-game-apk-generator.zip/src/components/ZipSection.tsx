import {
  ZIP_MANIFEST,
  PIPELINE_STAGES,
  ZIP_FILENAME,
  ZIP_SIZE,
  ZIP_FILE_COUNT,
  ENGINE_SHA_SHORT,
} from "@/data/content";
import { DownloadButton } from "@/components/DownloadButton";

export function ZipSection() {
  return (
    <section id="archive" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="reveal mb-10">
        <p className="font-mono text-[11px] tracking-[0.3em] text-gold">01 / DELIVERABLE — PROJECT ARCHIVE</p>
        <h2 className="mt-2 font-display text-5xl font-extrabold tracking-tight text-paper sm:text-6xl">
          THE ZIP. <span className="text-gold">REAL, VERIFIED,</span> BINARY-SAFE.
        </h2>
        <div className="hazard mt-4 w-56" />
      </div>

      <div className="grid gap-8 lg:grid-cols-[0.95fr_1.05fr]">
        {/* download card + pipeline */}
        <div className="reveal space-y-6">
          <div className="hud-panel hud-corners p-6">
            <div className="flex items-start gap-4">
              <span className="grid h-12 w-12 shrink-0 place-items-center border border-gold/60 bg-golddark/50">
                <svg viewBox="0 0 24 24" className="h-6 w-6 text-goldbright" fill="none" stroke="currentColor" strokeWidth="1.6">
                  <path d="M14 3H7a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V8z" />
                  <path d="M14 3v5h5" />
                  <path d="M12 11v6m0 0-2.2-2.2M12 17l2.2-2.2" />
                </svg>
              </span>
              <div className="min-w-0">
                <p className="truncate font-mono text-sm text-paper">{ZIP_FILENAME}</p>
                <p className="mt-1 font-mono text-[11px] text-muted">
                  {ZIP_SIZE} · {ZIP_FILE_COUNT} FILES · SHA-PINNED ENGINE REFERENCE · NO ROM, NO BIOS
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="border border-gold/50 bg-golddark/40 px-2 py-0.5 font-mono text-[10px] tracking-widest text-goldbright">INTEGRITY ✓</span>
                  <span className="border border-ice/40 bg-icedeep/30 px-2 py-0.5 font-mono text-[10px] tracking-widest text-ice">GPL-2.0 CLEAN</span>
                  <span className="border border-edge2 px-2 py-0.5 font-mono text-[10px] tracking-widest text-muted">UPLOAD AS-IS</span>
                </div>
              </div>
            </div>
            <DownloadButton variant="panel" className="mt-6" />
            <p className="mt-3 font-mono text-[10.5px] leading-relaxed text-faint">
              Upload this file — unmodified and unextracted — to your GitHub repository root.
              The workflow finds it, integrity-tests it, extracts it, and drives the whole build.
            </p>
          </div>

          {/* pipeline */}
          <div className="hud-panel p-6">
            <p className="mb-4 font-mono text-[10px] tracking-[0.3em] text-muted">ASSEMBLY LINE — ZIP → APK</p>
            <ol className="space-y-0">
              {PIPELINE_STAGES.map((s, i) => (
                <li key={s.n} className="group relative flex gap-4 pb-5 last:pb-0">
                  {i < PIPELINE_STAGES.length - 1 && (
                    <span className="absolute left-[15px] top-8 h-full w-px bg-edge group-hover:bg-gold/50" />
                  )}
                  <span className="relative z-10 grid h-8 w-8 shrink-0 place-items-center border border-edge2 bg-panel2 font-mono text-[10px] text-gold transition-colors group-hover:border-gold">
                    {s.n}
                  </span>
                  <div className="pt-1">
                    <p className="font-display text-lg font-bold tracking-[0.05em] text-paper">{s.t}</p>
                    <p className="font-mono text-[11px] leading-relaxed text-muted">{s.d}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* manifest */}
        <div className="reveal hud-panel hud-corners p-6">
          <div className="mb-4 flex items-center justify-between">
            <p className="font-mono text-[10px] tracking-[0.3em] text-muted">ARCHIVE MANIFEST</p>
            <p className="font-mono text-[10px] text-faint">unzip -l · verified</p>
          </div>
          <ul className="divide-y divide-edge/60">
            {ZIP_MANIFEST.map((f) => (
              <li key={f.path} className="group flex items-baseline gap-3 py-2.5 transition-colors hover:bg-panel2/70">
                <svg viewBox="0 0 16 16" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gold/70" fill="none" stroke="currentColor" strokeWidth="1.4">
                  <path d="M9.5 1.5H4.8a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h6.4a1 1 0 0 0 1-1V5.2z" />
                  <path d="M9.5 1.5v3.7h3.7" />
                </svg>
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="truncate font-mono text-[12px] text-goldbright">{f.path}</span>
                    <span className="shrink-0 font-mono text-[10px] text-faint">{f.size}</span>
                  </div>
                  <p className="font-mono text-[10.5px] leading-snug text-muted">{f.desc}</p>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-4 border border-bondred/40 bg-bondred/10 p-3">
            <p className="font-mono text-[10.5px] leading-relaxed text-paper/80">
              <span className="text-bondred2">⚠ LEGAL LINE:</span> the archive contains zero game
              data. GoldenEye 007 © 1997 Rare/Nintendo — you import your own cartridge dump
              (z64 / n64 / v64, plain or zipped) through the in-app ROM scan after install.
              Engine pinned at <span className="text-goldbright">{ENGINE_SHA_SHORT}</span>.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
