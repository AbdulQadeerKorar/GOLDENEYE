import { ENGINE_FACTS, GRAPHICS_MATRIX, HONEST_LIMITS, IMPLEMENTED } from "@/data/content";

function Mark({ s }: { s: "yes" | "no" | "warn" }) {
  if (s === "yes") return <span className="font-mono text-[12px] text-gold">■ WORKS</span>;
  if (s === "warn") return <span className="font-mono text-[12px] text-bondred2">■ HACK-LEVEL</span>;
  return <span className="font-mono text-[12px] text-muted">□ NOT OFFERED</span>;
}

export function CompatReport() {
  return (
    <section id="report" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="reveal mb-10">
        <p className="font-mono text-[11px] tracking-[0.3em] text-gold">05 / DELIVERABLE — COMPATIBILITY REPORT</p>
        <h2 className="mt-2 font-display text-5xl font-extrabold tracking-tight text-paper sm:text-6xl">
          WHAT'S WIRED. <span className="text-gold">WHAT'S HONEST.</span>
        </h2>
        <div className="hazard mt-4 w-56" />
      </div>

      {/* engine facts */}
      <div className="reveal hud-panel hud-corners mb-8 p-6">
        <p className="mb-4 font-mono text-[10px] tracking-[0.3em] text-muted">ENGINE FACT SHEET — MUPEN64PLUS-AE</p>
        <dl className="grid gap-x-10 gap-y-3 sm:grid-cols-2 lg:grid-cols-3">
          {ENGINE_FACTS.map((f) => (
            <div key={f.k} className="border-b border-edge/60 pb-2">
              <dt className="font-mono text-[10px] tracking-[0.25em] text-gold">{f.k}</dt>
              <dd className="mt-1 font-mono text-[11.5px] leading-snug text-paper/90">{f.v}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* implemented */}
        <div className="reveal hud-panel p-6">
          <p className="mb-4 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-gold">
            <span className="h-2 w-2 bg-gold" /> IMPLEMENTED &amp; WIRED TO REAL EMULATOR INPUT
          </p>
          <ul className="space-y-3.5">
            {IMPLEMENTED.map((row) => (
              <li key={row.f} className="group border-l-2 border-edge pl-4 transition-colors hover:border-gold">
                <p className="font-display text-lg font-bold tracking-[0.04em] text-paper">{row.f}</p>
                <p className="font-mono text-[11px] leading-relaxed text-muted">{row.d}</p>
              </li>
            ))}
          </ul>
        </div>

        <div className="space-y-8">
          {/* graphics matrix */}
          <div className="reveal hud-panel p-6">
            <p className="mb-4 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-ice">
              <span className="h-2 w-2 bg-ice" /> GRAPHICS — FEATURE × REAL ENGINE OPTION
            </p>
            <table className="w-full border-collapse">
              <tbody>
                {GRAPHICS_MATRIX.map((row) => (
                  <tr key={row.f} className="border-b border-edge/50 transition-colors last:border-0 hover:bg-panel2/60">
                    <td className="py-2 pr-3 font-display text-[15px] font-bold tracking-wide text-paper">{row.f}</td>
                    <td className="py-2 pr-3 whitespace-nowrap"><Mark s={row.s} /></td>
                    <td className="py-2 font-mono text-[10.5px] leading-snug text-muted">{row.via}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* honest limits */}
          <div className="reveal hud-panel p-6">
            <p className="mb-4 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-bondred2">
              <span className="h-2 w-2 bg-bondred2" /> HONEST LIMITATIONS — NOTHING HIDDEN BEHIND A WORKING UI
            </p>
            <ul className="space-y-3.5">
              {HONEST_LIMITS.map((row) => (
                <li key={row.f} className="border-l-2 border-bondred/50 pl-4">
                  <p className="font-display text-lg font-bold tracking-[0.04em] text-paper">{row.f}</p>
                  <p className="font-mono text-[11px] leading-relaxed text-muted">{row.d}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* verification ledger */}
      <div className="reveal mt-8 overflow-x-auto">
        <table className="w-full min-w-[720px] border-collapse border border-edge">
          <thead>
            <tr className="bg-panel2">
              <th className="border border-edge px-4 py-2.5 text-left font-mono text-[10px] tracking-[0.25em] text-gold">VERIFICATION — PERFORMED IN THIS SESSION</th>
              <th className="border border-edge px-4 py-2.5 text-left font-mono text-[10px] tracking-[0.25em] text-gold">RESULT</th>
              <th className="border border-edge px-4 py-2.5 text-left font-mono text-[10px] tracking-[0.25em] text-gold">DEFERRED TO</th>
            </tr>
          </thead>
          <tbody className="font-mono text-[11.5px]">
            {[
              ["ZIP archive assembled (18 files, 1.43 MB)", "PASSED — unzip -t clean", "—"],
              ["YAML workflow syntax", "PASSED — js-yaml parse, 18 steps", "—"],
              ["apply-overlay.sh end-to-end dry-run (mock engine tree)", "PASSED — label, applicationId, icons, verifications", "—"],
              ["Engine pin existence + upstream CI recipe", "PASSED — GitHub API @ 33bf7021", "—"],
              ["Gradle/NDK compile of the engine", "NOT RUN — no Android SDK/NDK in sandbox", "Your first GitHub Actions run"],
              ["On-device gameplay / touch / gamepad", "NOT RUN — no device available", "Your phone"],
            ].map(([a, b, c]) => (
              <tr key={a} className="transition-colors hover:bg-panel2/50">
                <td className="border border-edge px-4 py-2.5 text-paper/85">{a}</td>
                <td className={`border border-edge px-4 py-2.5 ${b.startsWith("PASSED") ? "text-gold" : "text-bondred2"}`}>{b}</td>
                <td className="border border-edge px-4 py-2.5 text-muted">{c}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
