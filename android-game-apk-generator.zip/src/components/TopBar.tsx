import { ENGINE_SHA_SHORT } from "@/data/content";

const NAV = [
  { href: "#archive", n: "01", t: "ARCHIVE" },
  { href: "#touchlab", n: "02", t: "TOUCH LAB" },
  { href: "#workflow", n: "03", t: "WORKFLOW" },
  { href: "#upload", n: "04", t: "UPLOAD" },
  { href: "#report", n: "05", t: "REPORT" },
];

export function TopBar() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-edge bg-abyss/85 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center gap-4 px-4 sm:px-6">
        {/* mark */}
        <a href="#briefing" className="group flex items-center gap-3">
          <span className="relative grid h-8 w-8 place-items-center border border-gold/70 bg-golddark/60">
            <svg viewBox="0 0 20 20" className="h-5 w-5 text-goldbright" fill="none" stroke="currentColor" strokeWidth="1.4">
              <circle cx="10" cy="10" r="5.2" />
              <path d="M10 1.5v4M10 14.5v4M1.5 10h4M14.5 10h4" />
              <circle cx="10" cy="10" r="1.1" fill="currentColor" stroke="none" />
            </svg>
          </span>
          <span className="leading-none">
            <span className="block font-display text-xl font-extrabold tracking-[0.08em] text-paper">
              GE<span className="text-gold">//</span>007
            </span>
            <span className="block font-mono text-[9px] tracking-[0.3em] text-muted">
              Q-BRANCH BUILD SYSTEM
            </span>
          </span>
        </a>

        <nav className="ml-auto hidden items-center gap-5 lg:flex">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="group font-mono text-[11px] tracking-[0.18em] text-muted transition-colors hover:text-goldbright"
            >
              <span className="text-gold/70 group-hover:text-goldbright">{item.n}</span>{" "}
              {item.t}
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-3 lg:ml-6">
          <span className="hidden items-center gap-1.5 font-mono text-[10px] tracking-widest text-muted sm:flex">
            <span className="led h-1.5 w-1.5 rounded-full bg-gold" />
            ZIP ✓
          </span>
          <span className="hidden items-center gap-1.5 font-mono text-[10px] tracking-widest text-muted md:flex">
            <span className="led h-1.5 w-1.5 rounded-full bg-ice" style={{ animationDelay: "0.8s" }} />
            YAML ✓
          </span>
          <span className="hidden items-center gap-1.5 font-mono text-[10px] tracking-widest text-muted lg:flex">
            <span className="led h-1.5 w-1.5 rounded-full bg-bondred2" style={{ animationDelay: "1.6s" }} />
            PIN {ENGINE_SHA_SHORT}
          </span>
        </div>
      </div>
      <div className="hazard" />
    </header>
  );
}
