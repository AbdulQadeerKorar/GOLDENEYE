import { useRef, useState } from "react";
import {
  ENGINE_SHA_SHORT,
  HERO_DOSSIER,
  TICKER_ITEMS,
  ZIP_FILENAME,
  ZIP_SIZE,
  ZIP_FILE_COUNT,
} from "@/data/content";
import { DownloadButton } from "@/components/DownloadButton";

function GunBarrel() {
  const cx = 200;
  const cy = 200;
  const rings: { r: number; spokes: number; offset: number }[] = [
    { r: 168, spokes: 28, offset: 0 },
    { r: 132, spokes: 22, offset: 9 },
    { r: 98, spokes: 18, offset: 20 },
  ];
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[430px]">
      {/* pulsing outer rings */}
      <div className="ring-pulse absolute inset-0 rounded-full border border-gold/40" />
      <div className="ring-pulse absolute inset-6 rounded-full border border-gold/30" style={{ animationDelay: "1.4s" }} />

      <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full">
        <defs>
          <radialGradient id="bore" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#05070a" />
            <stop offset="78%" stopColor="#0a0f16" />
            <stop offset="100%" stopColor="#141d2b" />
          </radialGradient>
          <linearGradient id="sweepGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="rgba(217,164,65,0.35)" />
            <stop offset="100%" stopColor="rgba(217,164,65,0)" />
          </linearGradient>
        </defs>

        <circle cx={cx} cy={cy} r={190} fill="url(#bore)" stroke="#243244" strokeWidth="2" />
        {rings.map((ring) => (
          <g key={ring.r} stroke="#33465e" strokeWidth="2.5" strokeLinecap="round">
            {Array.from({ length: ring.spokes }).map((_, i) => {
              const a1 = ((i * 360) / ring.spokes + ring.offset) * (Math.PI / 180);
              const a2 = a1 + 14 * (Math.PI / 180);
              const rIn = ring.r - 26;
              const x1 = cx + Math.cos(a1) * rIn;
              const y1 = cy + Math.sin(a1) * rIn;
              const x2 = cx + Math.cos(a2) * ring.r;
              const y2 = cy + Math.sin(a2) * ring.r;
              return <path key={i} d={`M${x1.toFixed(1)},${y1.toFixed(1)} L${x2.toFixed(1)},${y2.toFixed(1)}`} />;
            })}
            <circle cx={cx} cy={cy} r={ring.r} fill="none" stroke="#243244" strokeWidth="1.5" />
          </g>
        ))}

        {/* rotating radar sweep */}
        <g className="radar-sweep" style={{ transformOrigin: "200px 200px" }}>
          <path d={`M${cx},${cy} L${cx},${cy - 188} A188,188 0 0,1 ${cx + 96},${cy - 161} Z`} fill="url(#sweepGrad)" />
          <line x1={cx} y1={cy} x2={cx} y2={cy - 188} stroke="rgba(242,193,78,0.8)" strokeWidth="1.5" />
        </g>

        {/* bore + iris */}
        <circle cx={cx} cy={cy} r={58} fill="#05070a" stroke="#d9a441" strokeWidth="2" />
        <circle cx={cx} cy={cy} r={44} fill="none" stroke="#8a6420" strokeWidth="1" strokeDasharray="4 5" />
        <ellipse cx={cx} cy={cy} rx={13} ry={30} fill="none" stroke="#f2c14e" strokeWidth="2.5" />
        <ellipse cx={cx} cy={cy} rx={4.5} ry={24} fill="#3d2f12" />
        <circle cx={cx + 4} cy={cy - 12} r={2.4} fill="#e4574d" />

        {/* crosshair */}
        <g stroke="#6fbfc9" strokeWidth="1.4" opacity="0.9">
          <path d={`M${cx - 190},${cy} h26 M${cx + 164},${cy} h26 M${cx},${cy - 190} v26 M${cx},${cy + 164} v26`} />
        </g>
        <g fill="#7e8ca0" fontFamily="IBM Plex Mono, monospace" fontSize="11" letterSpacing="2">
          <text x={cx - 46} y={34}>GE//007</text>
          <text x={cx - 74} y={382}>FACILITY · ARCHIVE</text>
        </g>
      </svg>

      {/* status ledger */}
      <div className="hud-panel hud-corners absolute -bottom-6 left-1/2 w-[92%] -translate-x-1/2 px-4 py-3">
        <p className="mb-2 font-mono text-[10px] tracking-[0.3em] text-muted">MISSION STATUS</p>
        <ul className="space-y-1.5 font-mono text-[11px]">
          {[
            { t: `ZIP INTEGRITY — PASSED (${ZIP_FILE_COUNT} FILES)`, c: "bg-gold", d: "0s" },
            { t: "YAML PARSE — PASSED (JS-YAML)", c: "bg-ice", d: "0.5s" },
            { t: "OVERLAY DRY-RUN — PASSED (MOCK ENGINE)", c: "bg-bondred2", d: "1s" },
            { t: `ENGINE PIN — ${ENGINE_SHA_SHORT} (GITHUB API)`, c: "bg-gold", d: "1.5s" },
            { t: "NDK COMPILE — EXECUTES IN CI", c: "bg-bondred", d: "2s" },
          ].map((row) => (
            <li key={row.t} className="flex items-center gap-2 text-paper/85">
              <span className={`led h-1.5 w-1.5 shrink-0 rounded-full ${row.c}`} style={{ animationDelay: row.d }} />
              {row.t}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function Hero() {
  const zoneRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: -200, y: -200 });

  const onMove = (e: React.MouseEvent) => {
    const rect = zoneRef.current?.getBoundingClientRect();
    if (!rect) return;
    setPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  return (
    <section id="briefing" className="relative overflow-hidden pt-28 pb-10 sm:pt-32">
      <div ref={zoneRef} onMouseMove={onMove} onMouseLeave={() => setPos({ x: -200, y: -200 })} className="relative mx-auto max-w-7xl px-4 sm:px-6">
        {/* cursor crosshair */}
        <div
          className="pointer-events-none absolute z-10 hidden md:block"
          style={{ left: pos.x, top: pos.y, transform: "translate(-50%,-50%)" }}
        >
          <svg width="54" height="54" viewBox="0 0 54 54" className="opacity-70">
            <circle cx="27" cy="27" r="17" fill="none" stroke="#d9a441" strokeWidth="1" />
            <path d="M27 4v12M27 38v12M4 27h12M38 27h12" stroke="#d9a441" strokeWidth="1" />
            <circle cx="27" cy="27" r="1.6" fill="#e4574d" />
          </svg>
        </div>

        <div className="grid items-center gap-14 lg:grid-cols-[1.12fr_0.88fr]">
          {/* left — briefing */}
          <div className="flicker-in">
            <div className="mb-6 flex flex-wrap items-center gap-4">
              <span className="stamp px-3 py-1 text-[11px]">Classified</span>
              <span className="font-mono text-[11px] tracking-[0.25em] text-muted">
                MISSION BRIEFING · Q-7 / ANDROID DIVISION
              </span>
            </div>

            <h1 className="font-display font-black leading-[0.85] tracking-tight">
              <span className="block text-[clamp(3.4rem,9vw,7.5rem)] text-paper">GOLDENEYE</span>
              <span className="block text-[clamp(3.4rem,9vw,7.5rem)]">
                <span className="text-transparent" style={{ WebkitTextStroke: "2px #d9a441" }}>
                  007
                </span>
                <span className="ml-4 align-middle font-body text-sm font-semibold tracking-[0.2em] text-muted">
                  N64 → ANDROID APK
                </span>
              </span>
            </h1>

            <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-muted">
              A dedicated single-game build pipeline, not a generic multi-rom launcher. Verified
              project archive, SHA-pinned open-source N64 engine, and a GoldenEye-specific touch
              scheme — <span className="text-paper">camera under the right thumb, FIRE where your
              reflex expects it</span>. No bundled ROMs. No faked settings.
            </p>

            {/* dossier */}
            <dl className="mt-8 max-w-xl border-t border-edge">
              {HERO_DOSSIER.map((row) => (
                <div key={row.k} className="flex items-baseline gap-4 border-b border-edge/70 py-2 transition-colors hover:bg-panel/60">
                  <dt className="w-24 shrink-0 font-mono text-[10px] tracking-[0.25em] text-gold">{row.k}</dt>
                  <dd className="font-mono text-[12px] text-paper/90">{row.v}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <DownloadButton variant="hero" />
              <a href="#workflow" className="btn-ghost px-6 py-3.5 font-mono text-[12px] tracking-[0.15em]">
                READ THE WORKFLOW →
              </a>
            </div>
            <p className="mt-3 font-mono text-[11px] text-faint">
              {ZIP_FILENAME} · {ZIP_SIZE} · {ZIP_FILE_COUNT} files · integrity-checked in this session
            </p>
          </div>

          {/* right — gun barrel */}
          <div className="pb-16 lg:pb-8">
            <GunBarrel />
          </div>
        </div>
      </div>

      {/* ticker */}
      <div className="mt-16 border-y border-edge bg-deep/80">
        <div className="flex overflow-hidden py-2.5">
          <div className="ticker-track flex shrink-0 items-center gap-8 pr-8">
            {[...TICKER_ITEMS, ...TICKER_ITEMS].map((item, i) => (
              <span key={i} className="flex items-center gap-8 font-mono text-[11px] tracking-[0.2em] text-muted">
                {item} <span className="text-gold">✦</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
