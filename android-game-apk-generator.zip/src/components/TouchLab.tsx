import { useRef, useState } from "react";
import {
  C_DIRS,
  DEFAULT_LAYOUT,
  type ControlTone,
  type TouchControl,
} from "@/data/content";

interface LogEntry {
  id: number;
  time: string;
  text: string;
  tone: ControlTone;
}

const TONE: Record<ControlTone, { border: string; bg: string; text: string; glow: string }> = {
  gold: { border: "#d9a441", bg: "rgba(217,164,65,0.14)", text: "#f2c14e", glow: "rgba(217,164,65,0.35)" },
  red: { border: "#c93a32", bg: "rgba(201,58,50,0.18)", text: "#e4574d", glow: "rgba(228,87,77,0.4)" },
  ice: { border: "#6fbfc9", bg: "rgba(111,191,201,0.12)", text: "#9adde6", glow: "rgba(111,191,201,0.35)" },
  slate: { border: "#7e8ca0", bg: "rgba(126,140,160,0.12)", text: "#b7c2d2", glow: "rgba(126,140,160,0.3)" },
};

const cloneLayout = () => DEFAULT_LAYOUT.map((c) => ({ ...c }));

let logSeq = 0;
const now = () =>
  new Date().toLocaleTimeString("en-GB", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });

export function TouchLab() {
  const [layout, setLayout] = useState<TouchControl[]>(cloneLayout);
  const [editing, setEditing] = useState(false);
  const [moveMode, setMoveMode] = useState<"stick" | "dpad">("stick");
  const [lookZone, setLookZone] = useState(false);
  const [scale, setScale] = useState(100);
  const [opacity, setOpacity] = useState(85);
  const [log, setLog] = useState<LogEntry[]>([
    { id: logSeq++, time: now(), text: "SYSTEM → OVERLAY LOADED · PROFILE: GOLDENEYE-HONEY", tone: "gold" },
  ]);
  const [pressedId, setPressedId] = useState<string | null>(null);

  const stageRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ id: string; pid: number; sx: number; sy: number; ox: number; oy: number } | null>(null);
  const lookRef = useRef<{ pid: number; sx: number; sy: number; last: number } | null>(null);

  const pushLog = (text: string, tone: ControlTone) =>
    setLog((prev) => [{ id: logSeq++, time: now(), text, tone }, ...prev].slice(0, 8));

  const pulse = (id: string, msg: string, tone: ControlTone) => {
    if (editing) return;
    if (msg) pushLog(msg, tone);
    setPressedId(id);
    window.setTimeout(() => setPressedId((p) => (p === id ? null : p)), 180);
  };

  const startDrag = (e: React.PointerEvent, c: TouchControl) => {
    if (!editing) return;
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    dragRef.current = { id: c.id, pid: e.pointerId, sx: e.clientX, sy: e.clientY, ox: c.x, oy: c.y };
  };

  const moveDrag = (e: React.PointerEvent) => {
    const d = dragRef.current;
    const rect = stageRef.current?.getBoundingClientRect();
    if (!d || !rect || e.pointerId !== d.pid) return;
    const nx = Math.min(96, Math.max(4, d.ox + ((e.clientX - d.sx) / rect.width) * 100));
    const ny = Math.min(93, Math.max(6, d.oy + ((e.clientY - d.sy) / rect.height) * 100));
    setLayout((prev) => prev.map((c) => (c.id === d.id ? { ...c, x: nx, y: ny } : c)));
  };

  const endDrag = (e: React.PointerEvent) => {
    if (dragRef.current?.pid === e.pointerId) dragRef.current = null;
  };

  const lookDown = (e: React.PointerEvent) => {
    if (editing || !lookZone) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    lookRef.current = { pid: e.pointerId, sx: e.clientX, sy: e.clientY, last: 0 };
  };

  const lookMove = (e: React.PointerEvent) => {
    const l = lookRef.current;
    if (!l || e.pointerId !== l.pid) return;
    const t = Date.now();
    if (t - l.last < 160) return;
    l.last = t;
    const dx = Math.round(e.clientX - l.sx);
    const dy = Math.round(e.clientY - l.sy);
    l.sx = e.clientX;
    l.sy = e.clientY;
    pushLog(`TOUCH-LOOK → CAMERA Δx${dx >= 0 ? "+" : ""}${dx} Δy${dy >= 0 ? "+" : ""}${dy} (C-pad composite)`, "ice");
  };

  const reset = () => {
    setLayout(cloneLayout());
    setMoveMode("stick");
    setScale(100);
    setOpacity(85);
    pushLog("LAYOUT RESET → DEFAULT GOLDENEYE PROFILE RESTORED", "gold");
  };

  const s = scale / 100;
  const dim = opacity / 100;
  const controlStyle = (c: TouchControl) => ({
    left: `${c.x}%`,
    top: `${c.y}%`,
    width: c.w * s,
    opacity: dim,
  });

  const renderControl = (c: TouchControl) => {
    const tone = TONE[c.tone];
    const pressed = pressedId === c.id;
    const base =
      "touch-btn absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center text-center " +
      (editing ? "cursor-grab active:cursor-grabbing " : "cursor-pointer ") +
      (pressed ? "pressed " : "");

    if (c.kind === "ccluster") {
      const dir = c.w * s * 0.36;
      return (
        <div
          key={c.id}
          className={base}
          style={{ ...controlStyle(c), height: c.w * s }}
          onPointerDown={(e) => startDrag(e, c)}
          onPointerMove={moveDrag}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
        >
          {C_DIRS.map((d) => (
            <button
              key={d.id}
              aria-label={d.msg}
              className={`touch-btn absolute grid place-items-center border font-mono ${pressedId === d.id ? "pressed" : ""}`}
              style={{
                width: dir,
                height: dir,
                left: "50%",
                top: "50%",
                transform: `translate(-50%,-50%) translate(${d.dx * c.w * s * 0.31}px, ${d.dy * c.w * s * 0.31}px)`,
                borderColor: tone.border,
                background: tone.bg,
                color: tone.text,
                boxShadow: pressedId === d.id ? `0 0 18px ${tone.glow}` : `inset 0 0 10px rgba(0,0,0,0.4)`,
                pointerEvents: editing ? "none" : "auto",
              }}
              onPointerDown={(e) => {
                e.stopPropagation();
                pulse(d.id, d.msg, "gold");
              }}
            >
              <span className="text-[11px] leading-none">{d.label}</span>
            </button>
          ))}
          <span
            className="pointer-events-none absolute left-1/2 top-1/2 grid h-[15%] w-[15%] -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border font-mono text-[9px]"
            style={{ borderColor: tone.border, color: tone.text, background: "rgba(9,13,18,0.8)" }}
          >
            C
          </span>
          <span className="pointer-events-none absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap font-mono text-[9px] tracking-[0.25em]" style={{ color: tone.text }}>
            {c.label} · {c.sub}
          </span>
        </div>
      );
    }

    if (c.kind === "stick" || (c.id === "move" && moveMode === "stick")) {
      return (
        <div
          key={c.id}
          className={`${base} rounded-full border-2 border-dashed`}
          style={{ ...controlStyle(c), height: c.w * s, borderColor: tone.border, background: tone.bg }}
          onPointerDown={(e) => { startDrag(e, c); pulse(c.id, moveMode === "stick" ? c.msg : "D-PAD → P1 DIGITAL MOVE/TURN (4-way + diagonals)", c.tone); }}
          onPointerMove={moveDrag}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
        >
          <span className="grid h-[46%] w-[46%] place-items-center rounded-full border" style={{ borderColor: tone.border, background: "rgba(9,13,18,0.75)", boxShadow: pressed ? `0 0 22px ${tone.glow}` : "none" }} />
          <span className="mt-1.5 font-display text-[13px] font-bold tracking-[0.14em]" style={{ color: tone.text }}>{c.label}</span>
          <span className="font-mono text-[8px] tracking-[0.18em] text-muted">{moveMode === "stick" ? "TRUE ANALOG 0–127" : "DIGITAL 4-WAY"}</span>
        </div>
      );
    }

    if (c.id === "move" && moveMode === "dpad") {
      return (
        <div
          key={c.id}
          className={`${base}`}
          style={{
            ...controlStyle(c),
            height: c.w * s,
            background: tone.bg,
            border: `2px solid ${tone.border}`,
            clipPath:
              "polygon(35% 0%,65% 0%,65% 35%,100% 35%,100% 65%,65% 65%,65% 100%,35% 100%,35% 65%,0% 65%,0% 35%,35% 35%)",
            boxShadow: pressed ? `0 0 22px ${tone.glow}` : "none",
          }}
          onPointerDown={(e) => { startDrag(e, c); pulse(c.id, "D-PAD → P1 DIGITAL MOVE/TURN (4-way + diagonals)", c.tone); }}
          onPointerMove={moveDrag}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
        >
          <span className="font-display text-[12px] font-bold tracking-[0.14em]" style={{ color: tone.text }}>MOVE</span>
        </div>
      );
    }

    if (c.kind === "pill") {
      return (
        <div
          key={c.id}
          className={`${base} rounded-full border px-2`}
          style={{ ...controlStyle(c), height: 30 * s + 8, borderColor: tone.border, background: tone.bg, boxShadow: pressed ? `0 0 18px ${tone.glow}` : "inset 0 0 10px rgba(0,0,0,0.4)" }}
          onPointerDown={(e) => { startDrag(e, c); pulse(c.id, c.msg, c.tone); }}
          onPointerMove={moveDrag}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
        >
          <span className="font-display text-[13px] font-bold tracking-[0.16em]" style={{ color: tone.text }}>{c.label}</span>
        </div>
      );
    }

    // round action buttons
    return (
      <div
        key={c.id}
        className={`${base} rounded-full border-2`}
        style={{ ...controlStyle(c), height: c.w * s, borderColor: tone.border, background: `radial-gradient(circle at 35% 30%, ${tone.bg}, rgba(9,13,18,0.85) 75%)`, boxShadow: pressed ? `0 0 26px ${tone.glow}` : "inset 0 -6px 14px rgba(0,0,0,0.45)" }}
        onPointerDown={(e) => { startDrag(e, c); pulse(c.id, c.msg, c.tone); }}
        onPointerMove={moveDrag}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
      >
        {c.id === "fire" && (
          <svg viewBox="0 0 40 40" className="mb-0.5 h-[26%] w-[26%]" fill="none" stroke={tone.text} strokeWidth="2">
            <circle cx="20" cy="20" r="9" />
            <path d="M20 4v7M20 29v7M4 20h7M29 20h7" />
          </svg>
        )}
        <span className="font-display font-extrabold tracking-[0.12em]" style={{ color: tone.text, fontSize: Math.max(11, c.w * s * 0.155) }}>
          {c.label}
        </span>
        <span className="font-mono tracking-[0.14em] text-muted" style={{ fontSize: Math.max(7.5, c.w * s * 0.085) }}>{c.sub}</span>
      </div>
    );
  };

  return (
    <section id="touchlab" className="border-y border-edge bg-deep/60 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal mb-10">
          <p className="font-mono text-[11px] tracking-[0.3em] text-gold">02 / FIELD TEST — TOUCH CONTROL LAB</p>
          <h2 className="mt-2 font-display text-5xl font-extrabold tracking-tight text-paper sm:text-6xl">
            CAMERA ON THE <span className="text-gold">RIGHT THUMB.</span> FIRE WHERE REFLEX LIVES.
          </h2>
          <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-muted">
            GoldenEye 007 (default <span className="text-paper">1.1 Honey</span> style): Z fires, B acts, A swaps weapons,
            and the <span className="text-ice">C-buttons — the game's camera — sit under your right thumb</span>. This lab previews
            the default overlay spec: flip on <span className="text-goldbright">EDIT LAYOUT</span> and drag any control; switch it off and
            tap — every input below is the real N64 signal the APK sends to the core.
          </p>
          <div className="hazard mt-5 w-56" />
        </div>

        {/* toolbar */}
        <div className="reveal hud-panel mb-6 flex flex-wrap items-center gap-x-6 gap-y-4 px-5 py-4">
          <button
            onClick={() => { setEditing((v) => !v); pushLog(editing ? "EDIT MODE OFF → GAMEPLAY INPUTS LIVE" : "EDIT MODE ON → GAMEPLAY INPUTS LOCKED (drag freely)", "gold"); }}
            className={`flex items-center gap-3 border px-4 py-2 font-mono text-[11px] tracking-[0.2em] transition-colors ${editing ? "border-gold bg-golddark/60 text-goldbright" : "border-edge2 text-muted hover:border-gold/60"}`}
          >
            <span className={`relative h-4 w-8 rounded-full border ${editing ? "border-gold bg-gold/30" : "border-edge2 bg-panel"}`}>
              <span className={`absolute top-1/2 h-2.5 w-2.5 -translate-y-1/2 rounded-full transition-all ${editing ? "left-[18px] bg-goldbright" : "left-[3px] bg-faint"}`} />
            </span>
            EDIT LAYOUT
          </button>

          <div className="flex items-center gap-1 border border-edge2 p-1">
            {(["stick", "dpad"] as const).map((m) => (
              <button
                key={m}
                onClick={() => { setMoveMode(m); pushLog(m === "stick" ? "MOVE WIDGET → ANALOG STICK (true 0–127 axes)" : "MOVE WIDGET → D-PAD (digital, diagonals supported)", "slate"); }}
                className={`px-3 py-1.5 font-mono text-[11px] tracking-[0.18em] transition-colors ${moveMode === m ? "bg-gold text-abyss" : "text-muted hover:text-paper"}`}
              >
                {m === "stick" ? "STICK" : "D-PAD"}
              </button>
            ))}
          </div>

          <button
            onClick={() => { setLookZone((v) => !v); pushLog(lookZone ? "SWIPE-LOOK ZONE DISABLED" : "SWIPE-LOOK ZONE ON — drag the right half to sweep the camera", "ice"); }}
            className={`border px-4 py-2 font-mono text-[11px] tracking-[0.2em] transition-colors ${lookZone ? "border-ice bg-icedeep/40 text-ice" : "border-edge2 text-muted hover:border-ice/60"}`}
          >
            SWIPE-LOOK
          </button>

          <label className="flex items-center gap-3 font-mono text-[11px] tracking-[0.18em] text-muted">
            SCALE
            <input type="range" min={60} max={160} value={scale} onChange={(e) => setScale(Number(e.target.value))} className="w-28 accent-[#d9a441]" />
            <span className="w-10 text-goldbright">{scale}%</span>
          </label>

          <label className="flex items-center gap-3 font-mono text-[11px] tracking-[0.18em] text-muted">
            OPACITY
            <input type="range" min={25} max={100} value={opacity} onChange={(e) => setOpacity(Number(e.target.value))} className="w-28 accent-[#d9a441]" />
            <span className="w-10 text-goldbright">{opacity}%</span>
          </label>

          <button onClick={reset} className="ml-auto border border-bondred/60 px-4 py-2 font-mono text-[11px] tracking-[0.2em] text-bondred2 transition-colors hover:bg-bondred/15">
            ⟲ RESET DEFAULT
          </button>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.55fr_1fr]">
          {/* stage */}
          <div
            ref={stageRef}
            className="reveal relative aspect-[2/1] w-full touch-none select-none overflow-hidden border border-edge2 bg-abyss"
            style={{
              backgroundImage:
                "radial-gradient(ellipse 70% 85% at 50% 45%, rgba(20,29,43,0.9), rgba(9,13,18,0.98)), linear-gradient(rgba(126,140,160,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(126,140,160,0.06) 1px, transparent 1px)",
              backgroundSize: "100% 100%, 36px 36px, 36px 36px",
            }}
          >
            {/* fake game HUD */}
            <p className="pointer-events-none absolute left-4 top-3 font-mono text-[11px] tracking-[0.2em] text-ice/80">FACILITY · 00:07:31</p>
            <p className="pointer-events-none absolute bottom-3 left-4 font-mono text-[11px] tracking-[0.2em] text-paper/50">PP7 (S) — 7/32</p>
            <svg viewBox="0 0 60 60" className="pointer-events-none absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 text-ice/25" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="30" cy="30" r="14" />
              <path d="M30 8v10M30 42v10M8 30h10M42 30h10" />
            </svg>
            <p className="pointer-events-none absolute right-4 top-3 font-mono text-[10px] tracking-[0.25em] text-faint">
              {editing ? "EDIT MODE — INPUTS LOCKED" : "LIVE PREVIEW — TAP CONTROLS"}
            </p>

            {/* swipe-look zone */}
            {lookZone && (
              <div
                className="absolute inset-y-0 right-0 w-1/2 cursor-crosshair"
                style={{ background: "repeating-linear-gradient(-45deg, rgba(111,191,201,0.09) 0 8px, transparent 8px 18px)", borderLeft: "1px dashed rgba(111,191,201,0.4)" }}
                onPointerDown={lookDown}
                onPointerMove={lookMove}
                onPointerUp={() => (lookRef.current = null)}
                onPointerCancel={() => (lookRef.current = null)}
              >
                <span className="absolute right-3 top-1/2 -translate-y-1/2 rotate-90 font-mono text-[10px] tracking-[0.3em] text-ice/70">LOOK ZONE</span>
              </div>
            )}

            {layout.map(renderControl)}
          </div>

          {/* core input log */}
          <div className="reveal hud-panel hud-corners flex flex-col p-5">
            <div className="mb-3 flex items-center justify-between">
              <p className="font-mono text-[10px] tracking-[0.3em] text-muted">CORE INPUT LOG → P1</p>
              <span className={`led h-2 w-2 rounded-full ${editing ? "bg-bondred2" : "bg-gold"}`} />
            </div>
            <div className="code-scroll min-h-[220px] flex-1 space-y-1.5 overflow-y-auto font-mono text-[11px] leading-relaxed">
              {log.map((entry) => (
                <p key={entry.id} className="flex gap-2">
                  <span className="shrink-0 text-faint">{entry.time}</span>
                  <span style={{ color: TONE[entry.tone].text }}>{entry.text}</span>
                </p>
              ))}
            </div>
            <div className="mt-4 border-t border-edge pt-3">
              <p className="font-mono text-[10.5px] leading-relaxed text-muted">
                <span className="text-goldbright">MULTITOUCH:</span> hold MOVE and tap FIRE simultaneously —
                the relative stick re-centers on touch, so no direction ever sticks when a finger lifts,
                a call interrupts, or the app loses focus.
              </p>
            </div>
          </div>
        </div>

        {/* what ships in the APK */}
        <div className="reveal mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["PER-BUTTON EDITOR", "drag, exact H%/V% fields, free Scaling%, add/remove, auto-hold — the engine's real Buttons editor"],
            ["PROFILES", "named touchscreen profiles persisted across restarts (Honey / Solitaire / Portrait / custom)"],
            ["TRUE ANALOG", "stick widget feeds 0–127 axis values to the core — not a digital fake"],
            ["GAMEPADS", "Bluetooth/USB controller remapping, 4 player profiles, touch + pad combined mode"],
          ].map(([t, d]) => (
            <div key={t} className="border border-edge bg-panel p-4 transition-colors hover:border-gold/50">
              <p className="font-display text-lg font-bold tracking-[0.06em] text-gold">{t}</p>
              <p className="mt-1 font-mono text-[10.5px] leading-relaxed text-muted">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
