import { UPLOAD_STEPS, ZIP_FILENAME } from "@/data/content";

export function UploadGuide() {
  return (
    <section id="upload" className="border-y border-edge bg-deep/60 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal mb-10">
          <p className="font-mono text-[11px] tracking-[0.3em] text-gold">04 / DELIVERABLE — UPLOAD PROCEDURE</p>
          <h2 className="mt-2 font-display text-5xl font-extrabold tracking-tight text-paper sm:text-6xl">
            ZIP IN. <span className="text-gold">APK OUT.</span> NO LOCAL GIT REQUIRED.
          </h2>
          <div className="hazard mt-4 w-56" />
        </div>

        <div className="reveal mb-8 flex items-start gap-4 border border-bondred/40 bg-bondred/10 p-5">
          <svg viewBox="0 0 24 24" className="mt-0.5 h-6 w-6 shrink-0 text-bondred2" fill="none" stroke="currentColor" strokeWidth="1.6">
            <path d="M12 3 2.5 20h19L12 3z" />
            <path d="M12 10v4.5M12 17.5v.5" />
          </svg>
          <p className="font-mono text-[12px] leading-relaxed text-paper/85">
            <span className="text-bondred2">GITHUB LIMITATION — READ FIRST:</span> uploading a ZIP to a repository does{" "}
            <em>not</em> activate GitHub Actions. A workflow only exists once it is committed at{" "}
            <span className="text-goldbright">.github/workflows/</span>. That's why phase B below has you create the YAML
            file through the web UI — two minutes, no extraction, no terminal.
          </p>
        </div>

        <div className="grid gap-5 md:grid-cols-2">
          {UPLOAD_STEPS.map((step, i) => (
            <div key={step.phase} className="reveal hud-panel group p-6 transition-colors hover:border-gold/50">
              <div className="mb-3 flex items-center justify-between">
                <span className="border border-gold/50 bg-golddark/40 px-2.5 py-1 font-mono text-[10px] tracking-[0.25em] text-goldbright">
                  PHASE {step.phase}
                </span>
                <span className="font-display text-4xl font-extrabold text-edge2 transition-colors group-hover:text-gold/40">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <h3 className="font-display text-2xl font-bold tracking-tight text-paper">{step.title}</h3>
              <p className="mt-2 font-mono text-[11.5px] leading-relaxed text-muted">{step.body}</p>
            </div>
          ))}
        </div>

        <div className="reveal mt-8 hud-panel hud-corners flex flex-wrap items-center gap-x-8 gap-y-3 px-6 py-5">
          <p className="font-mono text-[11px] text-muted">
            <span className="text-goldbright">REPO LAYOUT AFTER PHASE B:</span>
          </p>
          <pre className="font-mono text-[11px] leading-relaxed text-ice/90">{`your-repo/
├── ${ZIP_FILENAME}      ← binary, never extracted
└── .github/workflows/android-build.yml`}</pre>
          <p className="ml-auto font-mono text-[11px] text-muted">
            ARTIFACT: <span className="text-goldbright">GoldenEye007-N64-apk</span> · retained 30 days
          </p>
        </div>
      </div>
    </section>
  );
}
