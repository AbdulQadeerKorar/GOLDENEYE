import { useRef, useState } from "react";
import { ZIP_FILENAME } from "@/data/content";
import { ZIP_URL } from "@/data/zip";

/**
 * Self-contained payload delivery: fetches the inlined data URI, converts it
 * to a Blob URL and triggers a real file download named GoldenEye007-N64-Project.zip.
 * Falls back to a direct data-URI anchor if the Blob path fails.
 */
export function DownloadButton({
  variant = "hero",
  className = "",
}: {
  variant?: "hero" | "panel";
  className?: string;
}) {
  const [state, setState] = useState<"idle" | "busy" | "done">("idle");
  const busyRef = useRef(false);

  const deliver = async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    setState("busy");
    const fireAnchor = (href: string) => {
      const a = document.createElement("a");
      a.href = href;
      a.download = ZIP_FILENAME;
      document.body.appendChild(a);
      a.click();
      a.remove();
    };
    try {
      const res = await fetch(ZIP_URL);
      const blob = await res.blob();
      const obj = URL.createObjectURL(blob);
      fireAnchor(obj);
      window.setTimeout(() => URL.revokeObjectURL(obj), 10000);
      setState("done");
    } catch {
      fireAnchor(ZIP_URL);
      setState("done");
    }
    window.setTimeout(() => {
      setState("idle");
      busyRef.current = false;
    }, 2800);
  };

  const label =
    state === "busy"
      ? "⏳ PACKAGING PAYLOAD…"
      : state === "done"
        ? "✓ DELIVERED — CHECK YOUR DOWNLOADS"
        : "⬇ DOWNLOAD PROJECT ZIP";

  const cls =
    variant === "panel"
      ? `btn-gold block w-full px-6 py-4 text-center font-display text-xl font-extrabold tracking-[0.08em] ${className}`
      : `btn-gold px-7 py-3.5 font-display text-lg font-extrabold tracking-[0.08em] ${className}`;

  return (
    <button type="button" onClick={deliver} className={cls} aria-label={`Download ${ZIP_FILENAME}`}>
      {label}
    </button>
  );
}
