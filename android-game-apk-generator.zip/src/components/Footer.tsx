export function Footer() {
  return (
    <footer className="border-t border-edge bg-abyss">
      <div className="hazard" />
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 md:grid-cols-[1.2fr_1fr_1fr]">
          <div>
            <p className="font-display text-3xl font-extrabold tracking-tight text-paper">
              GE<span className="text-gold">//</span>007
            </p>
            <p className="mt-3 max-w-sm font-mono text-[11px] leading-relaxed text-muted">
              A fan-made build pipeline. GoldenEye 007 © 1997 Rare Ltd. / Nintendo — no ROMs,
              BIOS files, or game data are distributed anywhere in this project. Bring your own
              legally obtained cartridge dump.
            </p>
          </div>
          <div>
            <p className="mb-3 font-mono text-[10px] tracking-[0.3em] text-gold">ENGINE ATTRIBUTION (GPL-2.0)</p>
            <ul className="space-y-1.5 font-mono text-[11px] text-muted">
              <li><a className="transition-colors hover:text-goldbright" href="https://github.com/mupen64plus-ae/mupen64plus-ae" target="_blank" rel="noreferrer">mupen64plus-ae/mupen64plus-ae</a></li>
              <li><a className="transition-colors hover:text-goldbright" href="https://github.com/mupen64plus" target="_blank" rel="noreferrer">github.com/mupen64plus</a></li>
              <li><a className="transition-colors hover:text-goldbright" href="https://github.com/gonetz/GLideN64" target="_blank" rel="noreferrer">gonetz/GLideN64</a></li>
            </ul>
          </div>
          <div>
            <p className="mb-3 font-mono text-[10px] tracking-[0.3em] text-gold">DELIVERY MANIFEST</p>
            <ul className="space-y-1.5 font-mono text-[11px] text-muted">
              <li>01 · GoldenEye007-N64-Project.zip — verified</li>
              <li>02 · android-build.yml — parsed ✓</li>
              <li>03 · GitHub web-UI procedure — no local git</li>
              <li>04 · Compatibility report — honest</li>
            </ul>
          </div>
        </div>
        <div className="mt-10 flex flex-wrap items-center justify-between gap-3 border-t border-edge/60 pt-5">
          <p className="font-mono text-[10px] tracking-[0.2em] text-faint">
            “THE WORLD IS NOT ENOUGH — BUT AN ARM64 BUILD PIPELINE IS.”
          </p>
          <p className="font-mono text-[10px] tracking-[0.2em] text-faint">Q-BRANCH · ANDROID DIVISION · {new Date().getFullYear()}</p>
        </div>
      </div>
    </footer>
  );
}
