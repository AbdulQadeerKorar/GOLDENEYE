import { TopBar } from "@/components/TopBar";
import { Hero } from "@/components/Hero";
import { ZipSection } from "@/components/ZipSection";
import { TouchLab } from "@/components/TouchLab";
import { WorkflowSection } from "@/components/WorkflowSection";
import { UploadGuide } from "@/components/UploadGuide";
import { CompatReport } from "@/components/CompatReport";
import { Footer } from "@/components/Footer";
import { useRevealAll } from "@/hooks/useReveal";

export default function App() {
  useRevealAll();
  return (
    <div className="min-h-screen">
      <div className="bg-field" />
      <div className="bg-grid" />
      <div className="scanlines" />
      <div className="noise" />
      <TopBar />
      <main>
        <Hero />
        <ZipSection />
        <TouchLab />
        <WorkflowSection />
        <UploadGuide />
        <CompatReport />
      </main>
      <Footer />
    </div>
  );
}
